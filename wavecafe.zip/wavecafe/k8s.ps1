Write-Output "Download the Kubernetes configuration file from a URL and save it locally"
wget "https://go.knts.app/link/C9FYx9yxTB5Rn8hc8" -o $pwd/kluster.yaml

Write-Output "Set the KUBECONFIG environment variable to point to the downloaded configuration file"
$Env:KUBECONFIG="$pwd/kluster.yaml"

Write-Output "Get information about the Kubernetes nodes"
kubectl get node

Write-Output "Apply the configuration from cafedep.yml to create a deployment"
kubectl apply -f cafedep.yml

# Pause for 3 seconds
Start-Sleep -Seconds 3

Write-Output "Get information about the deployed application"
kubectl get deployment

Write-Output "Apply the configuration from cafe-service.yml to create a service"
kubectl apply -f cafe-service.yml

# Pause for 3 seconds
Start-Sleep -Seconds 3

# Extract the application link
Write-Output "Extracting Application link"

# Get information about the service with 'wave' in its name and extract the port number
$svc = kubectl get svc | Select-String -Pattern 'wave'
$port = [regex]::Match($svc, ':\d+').Value

# Get the IP address of a Kubernetes pod named 'wav'
$ip = kubectl describe po wav | Select-String -Pattern 'Node:'
$ip = [regex]::Match($ip, '(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})').Value

# Construct and display the application link
$output = "http://$ip$port/"
Write-Output "Application Link $output"
